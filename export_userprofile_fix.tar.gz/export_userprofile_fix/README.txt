Updated files for UserProfile auto-open fix

Paths relative to project root:
- templates/base.html
- templates/dashboard.html
- companies/static/js/media.image.login.js
- companies/static/js/modals.crud.js
- companies/templates/companies/userprofile_modal_bare.html

Install by replacing these files in your project.
