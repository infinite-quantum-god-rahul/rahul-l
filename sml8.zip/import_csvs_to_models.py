#!/usr/bin/env python3
"""
Robust CSV to Django model importer with improved model matching and FK fallback support.
- Preserves previous logic and CLI.
- Adds richer FIELD_ALIASES for your updated models.py.
- Adds FK-specific alias lists (FK_ALIAS_MAP) for Branch/Center/Group/Village/Client/Staff.
- Safer type coercion (numbers with commas, Y/N booleans, dates in many formats incl. time).
- Handles curly quotes around values.
- Treats NA/N/A/- as None for numeric fields.
- Stores entire CSV row into raw_csv_data (unchanged).
"""

import os
import sys
import argparse
import csv
import time
import logging
from collections import defaultdict
from datetime import datetime

# Django setup
if "DJANGO_SETTINGS_MODULE" not in os.environ:
    os.environ["DJANGO_SETTINGS_MODULE"] = "spoorthi_macs.settings"
import django
django.setup()

from django.apps import apps
from django.db import transaction, OperationalError, close_old_connections
from django.db.models import ForeignKey
from django.utils.text import camel_case_to_spaces

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("csv_importer")

# ----------------------------
# Helpers
# ----------------------------

def normalize(name: str) -> str:
    return "".join(ch.lower() for ch in name if ch.isalnum())

def _strip_fancy_quotes(s: str) -> str:
    # remove curly/directional quotes
    return s.replace("“", "").replace("”", "").replace("‘", "").replace("’", "")

def fix_value(v):
    # Treat common "empty" tokens as None and strip quotes (incl. curly)
    if v is None:
        return None
    if isinstance(v, str):
        vv = _strip_fancy_quotes(v.strip().strip('"').strip("'"))
        if vv == "" or vv.lower() in ("nan", "none", "null", "na", "n/a", "-", "--"):
            return None
        return vv
    return v

# Accept both date-only and date-time variants
DATE_FORMATS = [
    # date only
    "%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%Y/%m/%d",
    "%d/%m/%y", "%d-%m-%y", "%m/%d/%Y", "%m-%d-%Y",
    "%m/%d/%y", "%m-%d-%y",
    # date + time
    "%d/%m/%Y %H:%M:%S", "%d-%m-%Y %H:%M:%S",
    "%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S",
    "%d/%m/%y %H:%M:%S", "%d-%m-%y %H:%M:%S",
    "%m/%d/%Y %H:%M:%S", "%m-%d-%Y %H:%M:%S",
    "%m/%d/%y %H:%M:%S", "%m-%d-%y %H:%M:%S",
]

def parse_date_maybe(raw):
    raw = fix_value(raw)
    if raw is None:
        return None
    s = str(raw)
    # Normalize separators & ISO-ish "T"
    s = _strip_fancy_quotes(s).replace("\\", "/").replace(".", "/").replace("T", " ").strip()
    # Try full string, then only date part if space present
    candidates = [s]
    if " " in s:
        candidates.append(s.split(" ", 1)[0])

    for cand in candidates:
        for fmt in DATE_FORMATS:
            try:
                return datetime.strptime(cand, fmt).date()
            except Exception:
                pass
    # Couldn’t parse → return None so DateField won't error
    return None

def to_bool(raw):
    s = str(raw).strip().lower()
    return s in ("1", "true", "yes", "y", "t")

def _looks_numeric(s: str) -> bool:
    s = s.replace(",", "").strip()
    if s in ("", ".", "-", "-."):
        return False
    if any(c.isalpha() for c in s):
        return False
    try:
        float(s)
        return True
    except Exception:
        return False

def to_number(raw, as_int=False):
    if raw is None:
        return None
    s = str(raw).replace(",", "").strip()
    if not _looks_numeric(s):
        return None
    try:
        if as_int:
            return int(float(s))
        return float(s)
    except Exception:
        return None  # be safe

def coerce_field_value(field, raw):
    """
    Preserve your logic, but for BooleanField: blank/missing -> False (not None),
    so NOT NULL booleans (e.g., during_the_week) don't fail.
    """
    internal_type = field.get_internal_type()

    # Special-case booleans BEFORE fix_value(None) early-return
    if internal_type == "BooleanField":
        # raw may be None/blank/"NA" -> treat as False
        rv = fix_value(raw)
        if rv is None:
            return False
        return to_bool(rv)

    raw = fix_value(raw)
    if raw is None:
        return None
    try:
        if internal_type in ("FloatField", "DecimalField"):
            return to_number(raw, as_int=False)
        if internal_type in ("IntegerField", "BigIntegerField", "SmallIntegerField", "AutoField",
                             "PositiveIntegerField", "PositiveSmallIntegerField"):
            return to_number(raw, as_int=True)
        if internal_type == "JSONField":
            import json
            try:
                return json.loads(raw)
            except Exception:
                return raw
        if internal_type == "DateField":
            return parse_date_maybe(raw)
        # Char/Text default
        return str(raw)
    except Exception:
        return None

# ----------------------------
# Model mapping
# ----------------------------

def build_model_map(app_config):
    model_map = {}
    for model in app_config.get_models():
        class_name = model.__name__
        norm1 = normalize(class_name)
        norm2 = normalize(camel_case_to_spaces(class_name).replace(" ", "_"))
        model_map[norm1] = model
        model_map[norm2] = model
    return model_map

# Field name aliases (CSV header -> model field)
FIELD_ALIASES = {
    # common identity/code/name
    'code1': 'code', 'sname': 'name', 'name1': 'name', 'names': 'name',

    # company/branch/village/center/group codes
    'branchid': 'code', 'branch_code': 'code',
    'vcode': 'code', 'villagecode': 'code', 'villageid': 'village',
    'centercode': 'code', 'centerid': 'center', 'centid': 'center',
    'groupcode': 'code', 'gcode': 'code', 'groupid': 'group',
    'mastercode': 'code', 'acode': 'code',  # accounting

    # members / client
    'smtcode': 'smtcode', 'membercode': 'smtcode', 'clientid': 'client', 'memono': 'smtcode',
    'mname': 'member_name',

    # phone / aadhar
    'phone': 'mobile', 'phoneno': 'mobile', 'mobile_no': 'mobile', 'contactno': 'contactno',
    'aadharno': 'aadhar', 'aadhaar': 'aadhar',

    # dates
    'tdate': 'date', 'doj': 'joining_date', 'dob': 'date_of_birth',
    'doc': 'doc_date', 'creat_date': 'created_on', 'create_date': 'created_on',

    # voucher / accounting
    'voucherno': 'voucher_no', 'voucher': 'voucher_no',

    # amounts
    'amount': 'loan_amount', 'loanamt': 'loan_amount',
    'prin': 'principal', 'int': 'interest',

    # center/group extra per your models
    'wday': 'week_day', 'rpmode': 'repayment_mode', 'mtime': 'meeting_time',
    'noofborrw': 'borrower_count', 'scode': 'schedule_code',
    'collday': 'coll_day', 'meetplace': 'meet_place', 'formedby': 'formed_by',
    'district': 'district', 'u_code': 'u_code', 'village': 'village',

    # staff extras
    'contact1': 'contact1', 'contact2': 'contact2', 'ifsc': 'ifsc', 'acno': 'acno',
}

# For ForeignKey fields, try these CSV columns in order if present
FK_ALIAS_MAP = {
    'company': ['company', 'companycode', 'company_id', 'companyid', 'cmp', 'cmpcode'],
    'branch':  ['branch', 'branchcode', 'branch_code', 'branchid', 'branch_id', 'brcode', 'br_code', 'branchname'],
    'village': ['village', 'villagecode', 'vcode', 'village_id', 'villageid', 'villagename', 'vname'],
    'center':  ['center', 'centercode', 'centid', 'center_id', 'centerid', 'cencode', 'centerno'],
    'group':   ['group', 'groupcode', 'gcode', 'group_id', 'groupid', 'grcode'],
    'client':  ['client', 'clientid', 'smtcode', 'membercode', 'smt'],
    'staff':   ['staff', 'staffcode', 'empcode', 'agent', 'agentcode'],
    'cadre':   ['cadre', 'cader', 'cadercode'],
    'account_head': ['account_head', 'acode', 'mastercode', 'acode_id', 'accounthead'],
    'voucher': ['voucher', 'voucherno', 'voucher_no', 'voucherid'],
}

def pick_first_present(row, keys):
    for k in keys:
        if k is None:
            continue
        # search case-insensitively
        for cand in (k, k.lower(), k.upper(), k.capitalize()):
            if cand in row:
                return cand
    return None

# ----------------------------
# FK resolution
# ----------------------------

def resolve_fk(field, raw_value, cache, fallback_values=None):
    rel_model = field.remote_field.model
    key = (rel_model, str(raw_value).strip()) if raw_value else (rel_model, "__fallback__")
    if key in cache:
        return cache[key]

    if raw_value:
        # Try by PK (digits)
        try:
            s = str(raw_value).strip()
            if s.isdigit():
                obj = rel_model.objects.filter(pk=int(s)).first()
                if obj:
                    cache[key] = obj
                    return obj
        except Exception:
            pass
        # Try by code then name/smtcode if present
        for attr in ("code", "smtcode", "name"):
            if hasattr(rel_model, attr):
                try:
                    obj = rel_model.objects.filter(**{attr: raw_value}).first()
                    if obj:
                        cache[key] = obj
                        return obj
                except Exception:
                    continue

    if fallback_values and rel_model in fallback_values:
        fallback = fallback_values[rel_model]
        logger.warning("⚠️ Using fallback for %s: '%s' → %s", rel_model.__name__, raw_value, fallback)
        cache[key] = fallback
        return fallback

    cache[key] = None
    return None

# ----------------------------
# Core import
# ----------------------------

def import_file(path, app_label, no_fk, batch_size):
    basename = os.path.basename(path)
    name_no_ext = os.path.splitext(basename)[0]
    norm_name = normalize(name_no_ext)

    app_config = apps.get_app_config(app_label)
    model_map = build_model_map(app_config)
    model = model_map.get(norm_name)
    if not model:
        logger.warning("⚠️ Skipping %-25s | No model found for '%s'", basename, norm_name)
        return

    logger.info("📥 Importing %-25s → model: %s", basename, model.__name__)
    fk_cache = {}
    success = 0
    failed = 0
    objs_batch = []

    # Fallback values for major parents (only if exist)
    fallback_values = {}
    for m in apps.get_app_config(app_label).get_models():
        if m.__name__.lower() in ("company", "branch", "center", "group", "village", "staff", "client", "accounthead", "voucher"):
            fallback = m.objects.first()
            if fallback:
                fallback_values[m] = fallback

    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            logger.warning("⚠️ Skipping %s: No headers", basename)
            return

        # Lowercased header map for fast lookup
        headers_lower = {h.lower(): h for h in reader.fieldnames if h}

        for idx, row in enumerate(reader, 1):
            data = {}
            skip_row = False

            for field in model._meta.get_fields():
                # skip auto and m2m
                if getattr(field, "auto_created", False) and not getattr(field, "concrete", False):
                    continue
                if field.many_to_many:
                    continue

                fname = field.name
                colname = field.column

                # ---------- FK handling ----------
                if field.is_relation and isinstance(field, ForeignKey):
                    val = None
                    if not no_fk:
                        # Gather candidate keys for this FK
                        aliases = FK_ALIAS_MAP.get(fname, [])
                        # Also consider the field name itself + _id variants
                        aliases = list(dict.fromkeys(aliases + [fname, f"{fname}_id"]))
                        # Add generic fallback from FIELD_ALIASES
                        ali = FIELD_ALIASES.get(fname.lower())
                        if ali:
                            aliases.append(ali)
                            aliases.append(f"{ali}_id")

                        # Find first present column in row (case-insensitive)
                        key_found = pick_first_present(row, aliases)
                        raw_val = row.get(key_found) if key_found else None

                        # If still not found, try using common code/name columns
                        if raw_val is None:
                            # E.g. center by 'CenterCode', group by 'GCode'
                            extras = {
                                'branch': ['Branchcode', 'BranchCode', 'BranchID'],
                                'village': ['VCode', 'VillageCode', 'VillageName', 'VName'],
                                'center': ['CenterCode', 'CentID', 'CenCode', 'CenNo', 'CenName', 'CenName1'],
                                'group':  ['GCode', 'GroupCode', 'GrCode'],
                                'client': ['SmtCode', 'MemberCode', 'ClientID', 'SMT'],
                                'staff':  ['StaffCode', 'EmpCode', 'Agent'],
                                'account_head': ['ACode', 'MasterCode'],
                                'voucher': ['VoucherNo', 'Voucher'],
                            }.get(fname, [])
                            key_found = pick_first_present(row, extras)
                            raw_val = row.get(key_found) if key_found else None

                        # Resolve FK
                        val = resolve_fk(field, fix_value(raw_val), fk_cache, fallback_values)

                        # If not-null FK, try fallback object of that model
                        if val is None and not field.null and field.remote_field.model in fallback_values:
                            val = fallback_values[field.remote_field.model]

                    data[fname] = val
                    continue

                # ---------- Non-FK fields ----------
                # Build candidate keys for this field
                possible_keys = [
                    fname, colname,
                    fname.lower() if fname else None,
                    colname.lower() if colname else None,
                    fname.upper() if fname else None,
                    colname.upper() if colname else None,
                    fname.capitalize() if fname else None,
                    colname.capitalize() if colname else None,
                    FIELD_ALIASES.get(fname.lower()),
                ]

                # Extra per your updated models
                extra_field_map = {
                    # Center
                    'coll_day': ['CollDay'],
                    'collection_day': ['Collection_day', 'CollectionDay'],
                    'meet_place': ['MeetPlace'],
                    'formed_by': ['FormedBy'],
                    'doc_date': ['DOC'],
                    'created_on': ['Creat_Date', 'Create_Date', 'CreatDate', 'CreateDate', 'creat_date'],
                    'u_code': ['U_Code', 'UCode'],
                    'vcode': ['VCode', 'vcode'],
                    'active_members': ['ActiveMembers', 'Active_Members'],
                    'groups_count': ['Groups', 'NoOfGroups'],
                    'members_count': ['Members', 'NoOfMembers'],
                    'prev_created_date': ['Prev_Creatdate', 'Prev_CreateDate'],
                    'split_info': ['Split_Inf', 'Split_Inf_'],
                    'negative_savings': ['NegetiveSavings', 'NegativeSavings'],
                    'during_the_week': ['DuringTheWeek'],
                    'is_arrear': ['IsArrear'],
                    'record_ref': ['Record'],

                    # Group
                    'week_day': ['WDay', 'WeekDay'],
                    'repayment_mode': ['RPMode'],
                    'meeting_time': ['MTime'],
                    'borrower_count': ['noofBorrw', 'NoOfBorrowers'],
                    'schedule_code': ['SCode'],

                    # Staff
                    'contact1': ['Contact1', 'Mobile', 'PhoneNo'],
                    'contact2': ['Contact2', 'AltPhone', 'AlternatePhone'],
                    'adharno': ['AdharNo', 'Aadhaar'],
                    'bank_branch': ['Bank Branch', 'BankBranch'],

                    # Client
                    'join_date': ['Doj', 'JoinDate'],
                    'village_code': ['VillageCode'],
                    'relation': ['RelationShip', 'Relation'],
                }.get(fname, [])

                possible_keys.extend(extra_field_map)

                # Find a present header (case-insensitive)
                found_key = None
                for cand in possible_keys:
                    if not cand:
                        continue
                    k = cand
                    if k in row:
                        found_key = k
                        break
                    kl = k.lower()
                    if kl in headers_lower:
                        found_key = headers_lower[kl]
                        break

                if found_key:
                    # Special case: raw_csv_data should store the whole row
                    if field.get_internal_type() == "JSONField" and fname == "raw_csv_data":
                        data[fname] = row
                    else:
                        data[fname] = coerce_field_value(field, row[found_key])

            # Ensure extra_data.company_id=1 if model has extra_data field (preserving your prior behavior)
            if "extra_data" in [f.name for f in model._meta.get_fields()]:
                current = data.get("extra_data") or {}
                if isinstance(current, dict) and "company_id" not in current:
                    current["company_id"] = 1
                data["extra_data"] = current

            if "raw_csv_data" in [f.name for f in model._meta.get_fields()]:
                data.setdefault("raw_csv_data", row)

            # Build instance + unique-dup check
            try:
                obj = model(**data)

                # Skip duplicates for unique fields to avoid IntegrityError
                for field in model._meta.fields:
                    if getattr(field, "unique", False) and field.name in data and data[field.name] not in (None, ""):
                        if model.objects.filter(**{field.name: data[field.name]}).exists():
                            logger.warning("[%s] Duplicate %s skipped: %s", model.__name__, field.name, data[field.name])
                            skip_row = True
                            break
                if skip_row:
                    failed += 1
                    continue

                objs_batch.append(obj)
                if len(objs_batch) >= batch_size:
                    safe_bulk_create(model, objs_batch, batch_size)
                    success += len(objs_batch)
                    objs_batch.clear()
            except Exception as e:
                logger.error("[%s] Row %s error: %s", model.__name__, idx, e)
                failed += 1

    if objs_batch:
        try:
            safe_bulk_create(model, objs_batch, batch_size)
            success += len(objs_batch)
        except Exception as e:
            logger.warning("[%s] Bulk insert error: %s. Trying individual insert to skip duplicates...", model.__name__, e)
            for obj in objs_batch:
                try:
                    obj.save()
                    success += 1
                except Exception as e2:
                    logger.error("[%s] Save failed for object %s: %s", model.__name__, obj, e2)
                    failed += 1

    logger.info("✅ [%s] Imported: %d OK, %d Failed", model.__name__, success, failed)

# ----------------------------
# Bulk create with reconnects
# ----------------------------

def safe_bulk_create(model_class, objs, batch_size=500, retries=3):
    if not objs:
        return
    for attempt in range(1, retries + 1):
        try:
            with transaction.atomic():
                model_class.objects.bulk_create(objs, batch_size=batch_size)
            return
        except OperationalError as e:
            msg = str(e)
            code = e.args[0] if (len(e.args) > 0 and isinstance(e.args[0], int)) else None
            if code in (2006, 2013) or "server has gone away" in msg.lower() or "lost connection" in msg.lower():
                logger.warning("Lost connection on attempt %s/%s for %s; reconnecting: %s",
                               attempt, retries, model_class.__name__, e)
                close_old_connections()
                time.sleep(2 ** attempt)
                continue
            else:
                logger.error("Unrecoverable DB error: %s", e)
                raise
    raise RuntimeError(f"Bulk create failed for {model_class.__name__}")

# ----------------------------
# CLI
# ----------------------------

def main():
    parser = argparse.ArgumentParser(description="Robust CSV Importer for Django.")
    parser.add_argument("--csv-dir", required=True, help="Directory with CSVs")
    parser.add_argument("--app", required=True, help="Django app label")
    parser.add_argument("--no-fk", action="store_true", help="Disable FK resolution")
    parser.add_argument("--batch-size", type=int, default=500, help="Batch size for bulk_create")

    args = parser.parse_args()

    if not os.path.isdir(args.csv_dir):
        logger.error("❌ Directory not found: %s", args.csv_dir)
        sys.exit(1)

    csv_files = sorted([
        os.path.join(dp, f) for dp, _, files in os.walk(args.csv_dir)
        for f in files if f.lower().endswith(".csv")
    ])
    if not csv_files:
        logger.error("❌ No CSV files found in %s", args.csv_dir)
        sys.exit(1)

    # ---- PRIORITY ORDER to ensure parents before children (fixes village->center FK) ----
    PRIORITY = [
        "company", "branch", "village", "center", "group",
        "cadre", "staff", "userprofile",
        "product", "client",
        "loanapplication", "loanapproval", "disbursement",
        "accounthead", "voucher", "posting", "recoveryposting",
        "fieldschedule", "fieldreport", "weeklyreport", "monthlyreport",
        "column"
    ]
    def priority_key(path):
        base = os.path.splitext(os.path.basename(path))[0]
        norm = normalize(base)
        try:
            i = PRIORITY.index(norm)
        except ValueError:
            i = 999
        return (i, base.lower())

    csv_files = sorted(csv_files, key=priority_key)
    # -------------------------------------------------------------------------------

    for file in csv_files:
        try:
            import_file(file, args.app, args.no_fk, args.batch_size)
        except Exception as e:
            logger.error("❌ Import failed for %s: %s", file, e)

    logger.info("🎉 All imports completed.")

if __name__ == "__main__":
    main()
