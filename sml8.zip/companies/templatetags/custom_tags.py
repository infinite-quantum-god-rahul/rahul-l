# companies/templatetags/custom_tags.py
from django import template
from datetime import date, datetime
from collections import defaultdict
import re

register = template.Library()

# ======= Safe Attribute Getter ======= #
@register.filter
def attr(obj, attr_name):
    if obj is None or attr_name is None:
        return ''
    try:
        return getattr(obj, attr_name, '')
    except AttributeError:
        return ''

@register.filter(name='get_attr')
def get_attr(obj, attr_name):
    return attr(obj, attr_name)

# ======= Classname for Type Checking ======= #
@register.filter
def classname(obj):
    return obj.__class__.__name__.lower() if obj else ''

# ======= Safe Dict/Object Getter ======= #
@register.filter
def get_item(container, key):
    if hasattr(container, 'get'):
        return container.get(key, '')
    try:
        return getattr(container, key)
    except AttributeError:
        return ''

# ======= Dynamic Form Field Lookup ======= #
@register.filter
def get_field(form, name):
    try:
        return form[name]
    except Exception:
        return ''

# ======= Flatten any iterable-of-iterables one level ======= #
@register.filter
def flatten(value):
    try:
        result = []
        for sub in value:
            if hasattr(sub, '__iter__') and not isinstance(sub, (str, bytes)):
                result.extend(sub)
            else:
                result.append(sub)
        return result
    except Exception:
        return []

# ======= Date Formatting (dd/mm/yyyy) ======= #
@register.filter
def format_ddmmyyyy(value):
    if isinstance(value, (date, datetime)):
        return value.strftime('%d/%m/%Y')
    return value

# ======= Check for DateField in Form ======= #
@register.filter
def is_datefield(field):
    try:
        return field.field.__class__.__name__ == 'DateField'
    except Exception:
        return False

# ======= Add Class to Form Fields ======= #
@register.filter
def add_class(field, css_class):
    if hasattr(field.field.widget, 'attrs'):
        existing = field.field.widget.attrs.get('class', '')
        field.field.widget.attrs['class'] = f"{existing} {css_class}".strip()
    return field

# ======= Field Existence Check ======= #
@register.filter
def has_field(form, field_name):
    return field_name in getattr(form, 'fields', {})

# ======= Group Permissions by Category ======= #
@register.filter
def group_permissions(choices):
    grouped = defaultdict(list)
    for perm_id, name in choices:
        lname = name.lower()
        if 'master' in lname:
            grouped['Master'].append((perm_id, name))
        elif 'entry' in lname:
            grouped['Data Entry'].append((perm_id, name))
        elif 'report' in lname:
            grouped['Reports'].append((perm_id, name))
        else:
            grouped['Other'].append((perm_id, name))
    return grouped.items()

# ======= Split String ======= #
@register.filter
def split(value, delimiter):
    if value and delimiter:
        return value.split(delimiter)
    return []

# ======= Replace Underscores with Spaces ======= #
@register.filter
def replace_underscore(value):
    return str(value).replace('_', ' ').capitalize()

# ======= Check for File Extension ======= #
@register.filter
def is_file_path(value):
    if not isinstance(value, str):
        return False
    return any(value.lower().endswith(ext) for ext in [
        '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.pdf',
        '.doc', '.docx', '.xls', '.xlsx'
    ])

# ======= Check Value in Comma-Separated List ======= #
@register.filter
def in_list(value, arg):
    return str(value).strip() in [item.strip() for item in arg.split(',')]

# ======= Flatten Section Map ======= #
@register.filter
def flatten_list(section_map):
    return [item for _, fields in section_map for item in fields]

# ======= Field Label Overrides ======= #
@register.filter
def label_override(field_name):
    custom_labels = {
        'loanapproval': 'Loan Approval / Credit Verification',
        'userprofile': 'User Profile',
        'staffregistration': 'Staff Registration',
        'clientjoining': 'Client Joining',
        'businesssetting': 'Business Setting',
        'productsmanagement': 'Products Management',
        'fieldreport': 'Field Report',
        'loanapplication': 'Loan Application',
        'rolemanagement': 'Role Management',
        'fieldschedule': 'Field Schedule',
        'weeklyreport': 'Weekly Report',
        'monthlyreport': 'Monthly Report',
    }
    if not field_name:
        return ''
    key = field_name.lower()
    if key in custom_labels:
        return custom_labels[key]
    spaced = re.sub(r'(?<!^)(?=[A-Z])', ' ', field_name).replace('_', ' ')
    return spaced.title()

# ======= Get All Fields from Model Object (skip id/raw_csv_data) ======= #
@register.filter
def get_fields(obj):
    try:
        return [f for f in obj._meta.fields if f.name not in ('id', 'raw_csv_data')]
    except Exception:
        return []

# ======= Pretty formatter (underscores → spaces, title case) ======= #
@register.filter
def pretty(value):
    if value is None:
        return ''
    return str(value).replace('_', ' ').title()

# ======= Pretty Name Mapping (for sidebar and headings) ======= #
@register.filter
def pretty_name(model_name):
    pretty_names = {
        "loanapplication": "Loan Application",
        "clientjoiningform": "Client Joining Form",
        "userprofile": "User Profile",
        "staff": "Staff Registration",
        "role": "Role Management",
        "product": "Products Management",
        "column": "Custom Fields",
        "businesssetting": "Business Setting Rules",
        "fieldschedule": "Field Schedule",
        "fieldreport": "Field Report",
        "accounthead": "Account Head",
        "voucher": "Voucher Entry",
        "posting": "Ledger Posting",
        "recoveryposting": "Recovery Posting",
        "loanapproval": "Loan Approval",
        "disbursement": "Loan Disbursement",
        "cadre": "Cadre",
        "weeklyreport": "Weekly Report",
        "monthlyreport": "Monthly Report",
    }
    return pretty_names.get(str(model_name).lower(), model_name.replace('_', ' ').title())
