from django.contrib import admin
from .models import UserProfile
@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("get_username", "is_admin", "is_master", "is_data_entry", "is_reports", "is_accounting")
    list_filter = ("is_admin", "is_master", "is_data_entry", "is_reports", "is_accounting")
    search_fields = ("user__username", "user__email")

    @admin.display(description='Username')
    def get_username(self, obj):
        return obj.user.username
