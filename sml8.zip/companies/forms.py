from django import forms
from django.forms import TextInput, ClearableFileInput
from .models import (
    # core
    Company, Branch, Village, Center, Group, Role, UserProfile, Staff,
    Product, Client, LoanApplication, LoanApproval, Disbursement,
    BusinessSetting, FieldSchedule, FieldReport, WeeklyReport, MonthlyReport, Column, Cadre,
    # new business tables
    AccountHead, Voucher, Posting, RecoveryPosting,
    # ⇣ auto-generated CSV models stay below ⇣
    AccCashbook, AccCashbookold, AccHeads, Aadhar, Accfundloancols, Accfundloans,
    Accountmaster, Arrear, Cheque, Codes, Contacts, Dayend, Equity2,
    Equityshare31032014, Equityshare31032015, Gr, Groups, MXAgent, MXCode,
    MXMember, MXSavings, Massposting, MasterBranch, MasterCategories, MasterFs,
    MasterLoanpurposes, MasterLoantypes, MasterMonth, MasterSectors, MasterSetup,
    MasterWeeks, MXAgriment, MXLoancols, MXLoans, MXSalaries, Pdc, RptDaybook,
    Securitydeposit, Staffloans, Transefer, Cobarower, Collectionrpt, Fund,
    Loancols, Loans, Loansmfi41110, Mloanschedule, Mloancols, Mloans, Mlogin,
    Mmisc, Mrecvisit, Msetup, Msurity, MasterBusinessmode, Memberdeposits,
    Members, Memberskaikaluru, Pbdet, Rptincome, RptGrcollectionsheet,
    RptOutstanding, RptPassbook, RptPassbookcommon, RptTb, RptDisRegister,
    RptHigh, RptSavings, RptSumsheet, Savings, Setup, Setupn, Share, Share1,
    Smtavail, Temp, Users,
    # validators
    phone_validator, aadhar_validator
)

# ─────────  SHARED BASE  ─────────
from django.utils.timezone import localdate
from django import forms
from django.forms import TextInput, ClearableFileInput
from django.utils import timezone

class ExcludeRawCSVDataForm(forms.ModelForm):
    class Meta:
        exclude = ["raw_csv_data"]

    def __init__(self, *args, **kwargs):
        self.extra_fields = kwargs.pop("extra_fields", [])
        super().__init__(*args, **kwargs)

        for name, field in self.fields.items():
            # 🗓 joining_date: prefill today, readonly, flatpickr, dd/mm/yyyy
            if name == "joining_date":
                today_str = localdate().strftime("%d/%m/%Y")

                # Set only if no value in POST, no initial, and no instance value
                if (
                        not self.data.get(name)
                        and not self.initial.get(name)
                        and not getattr(self.instance, name)
                ):
                    field.initial = today_str
                    self.initial[name] = today_str

                field.widget.attrs.update({
                    "readonly": "readonly",
                    "class": "form-control",
                    "placeholder": "dd/mm/yyyy",
                    "autocomplete": "off",
                    "style": "pointer-events: none; background-color: #e9ecef;",
                    "data-no-flatpickr": "true",
                })

                if (
                    not self.data.get(name)
                    and not self.initial.get(name)
                    and not getattr(self.instance, name)
                ):
                    self.initial[name] = today_str
                    field.initial = today_str

            # 🆔 Aadhar formatting (12 digits, spaced)
            elif name == "adharno":
                field.widget.attrs.update({
                    "placeholder": "0000 0000 0000",
                    "maxlength": "14",
                    "class": "form-control aadhar-input",
                    "inputmode": "numeric",
                    "autocomplete": "off",
                    "pattern": r"\d{4}\s\d{4}\s\d{4}",
                    "title": "Enter Aadhar in 0000 0000 0000 format using only digits",
                    "oninput": "this.value=this.value.replace(/[^0-9 ]/g,'').replace(/(\d{4})\s?(\d{0,4})\s?(\d{0,4})/, '$1 $2 $3').trim()",
                })


            elif name in ("phone", "mobile", "contact1", "housecontactno"):
                css = field.widget.attrs.get("class", "form-control")
                field.widget.attrs.update({
                    "class": f"{css} phone-input".strip(),
                    "placeholder": "10-digit number",
                    "maxlength": "10",
                    "inputmode": "numeric",
                    "autocomplete": "off",
                    "pattern": r"\d{10}",
                    "title": "Enter 10-digit phone number using only digits",
                    "oninput": "this.value=this.value.replace(/\\D/g,'')",
                })


            # 🆔 Code handling
            elif name == "code":
                field.widget.attrs.setdefault("class", "form-control autocode")
                if not self.instance.pk:
                    field.widget.attrs["readonly"] = "readonly"
                    field.widget.attrs["placeholder"] = "auto"
                else:
                    field.widget.attrs.pop("readonly", None)

            # 🖼 File/Image Fields
            elif isinstance(field, (forms.ImageField, forms.FileField)):
                field.widget = ClearableFileInput(attrs={"class": "form-control"})

            # 🗓 Other DateFields
            elif isinstance(field, forms.DateField):
                field.input_formats = ["%d/%m/%Y"]
                field.widget = TextInput(attrs={
                    "class": "date-field form-control",
                    "placeholder": "dd/mm/yyyy",
                    "data-flatpickr": "true",
                    "autocomplete": "off",
                })

            # 🧩 Default styling
            elif not isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.setdefault("class", "form-control")

        # ➕ Inject extra fields from Column model (Company ID 1)
        for col in self.extra_fields:
            field_kwargs = {
                "label": col.label,
                "required": col.required,
                "widget": TextInput(attrs={"class": "form-control"}),
            }

            if col.field_type == "date":
                field_cls = forms.DateField
                field_kwargs["widget"] = TextInput(attrs={
                    "class": "date-field form-control",
                    "placeholder": "dd/mm/yyyy",
                    "data-flatpickr": "true",
                    "autocomplete": "off",
                })
                field_kwargs["input_formats"] = ["%d/%m/%Y"]

            elif col.field_type == "number":
                field_cls = forms.DecimalField

            elif col.field_type == "file":
                field_cls = forms.FileField
                field_kwargs["widget"] = ClearableFileInput(attrs={"class": "form-control"})

            else:
                field_cls = forms.CharField

            self.fields[f"extra__{col.field_name}"] = field_cls(**field_kwargs)


# ─────────  CORE DOMAIN FORMS  ─────────
class CompanyForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Company
        fields = "__all__"

class BranchForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Branch
        fields = "__all__"

class VillageForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Village
        fields = "__all__"

class CenterForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Center
        fields = "__all__"

class GroupForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Group
        fields = "__all__"

class RoleForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Role
        exclude = ExcludeRawCSVDataForm.Meta.exclude + ["permissions"]

class UserProfileForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = UserProfile
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.section_map = getattr(self, "section_map", {})
        self.section_map.setdefault("Permissions", []).extend([
            "is_admin", "is_master", "is_data_entry", "is_reports", "is_accounting"
        ])
        self.section_map.setdefault("Status", []).append("status")

class StaffForm(ExcludeRawCSVDataForm):
    adharno  = forms.CharField(
        validators=[aadhar_validator],
        widget=TextInput(attrs={"placeholder": "0000 0000 0000"})
    )
    contact1 = forms.CharField(validators=[phone_validator], required=False)
    housecontactno = forms.CharField(validators=[phone_validator], required=False)

    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Staff
        fields = "__all__"

    def clean(self):
        cleaned_data = super().clean()
        aadhar = cleaned_data.get("adharno")
        contact = cleaned_data.get("contact1")

        if aadhar and Staff.objects.exclude(pk=self.instance.pk).filter(adharno=aadhar).exists():
            self.add_error("adharno", "Aadhar number already exists.")

        if contact and Staff.objects.exclude(pk=self.instance.pk).filter(contact1=contact).exists():
            self.add_error("contact1", "Contact number already exists.")

class ProductForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Product
        fields = "__all__"

class ClientForm(ExcludeRawCSVDataForm):
    aadhar = forms.CharField(
        validators=[aadhar_validator],
        widget=TextInput(attrs={"placeholder": "0000 0000 0000"})
    )
    contactno = forms.CharField(validators=[phone_validator], required=False)

    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Client
        fields = "__all__"

    def clean(self):
        cleaned_data = super().clean()
        aadhar = cleaned_data.get("aadhar")
        contact = cleaned_data.get("contactno")

        if aadhar and Client.objects.exclude(pk=self.instance.pk).filter(aadhar=aadhar).exists():
            self.add_error("aadhar", "Aadhar number already exists.")

        if contact and Client.objects.exclude(pk=self.instance.pk).filter(contactno=contact).exists():
            self.add_error("contactno", "Contact number already exists.")

class LoanApplicationForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = LoanApplication
        fields = "__all__"

class LoanApprovalForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = LoanApproval
        fields = "__all__"

class DisbursementForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Disbursement
        fields = "__all__"

class BusinessSettingForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = BusinessSetting
        fields = "__all__"

class FieldScheduleForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = FieldSchedule
        fields = "__all__"

class FieldReportForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = FieldReport
        fields = "__all__"

class WeeklyReportForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = WeeklyReport
        fields = "__all__"

class MonthlyReportForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = MonthlyReport
        fields = "__all__"

class ColumnForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Column
        fields = "__all__"

class CadreForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Cadre
        fields = "__all__"

# ─────────  NEW BUSINESS TABLE FORMS  ─────────
class AccountHeadForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = AccountHead
        fields = "__all__"

class VoucherForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Voucher
        fields = "__all__"

class PostingForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = Posting
        fields = "__all__"

class RecoveryPostingForm(ExcludeRawCSVDataForm):
    class Meta(ExcludeRawCSVDataForm.Meta):
        model = RecoveryPosting
        fields = "__all__"

# ─────────  AUTO-GENERATED FORMS FOR CSV TABLES  ─────────
_csv_models = [
    AccCashbook, AccCashbookold, AccHeads, Aadhar, Accfundloancols, Accfundloans,
    Accountmaster, Arrear, Cheque, Codes, Contacts, Dayend, Equity2,
    Equityshare31032014, Equityshare31032015, Gr, Groups, MXAgent, MXCode,
    MXMember, MXSavings, Massposting, MasterBranch, MasterCategories, MasterFs,
    MasterLoanpurposes, MasterLoantypes, MasterMonth, MasterSectors, MasterSetup,
    MasterWeeks, MXAgriment, MXLoancols, MXLoans, MXSalaries, Pdc, RptDaybook,
    Securitydeposit, Staffloans, Transefer, Cobarower, Collectionrpt, Fund,
    Loancols, Loans, Loansmfi41110, Mloanschedule, Mloancols, Mloans, Mlogin,
    Mmisc, Mrecvisit, Msetup, Msurity, MasterBusinessmode, Memberdeposits,
    Members, Memberskaikaluru, Pbdet, Rptincome, RptGrcollectionsheet,
    RptOutstanding, RptPassbook, RptPassbookcommon, RptTb, RptDisRegister,
    RptHigh, RptSavings, RptSumsheet, Savings, Setup, Setupn, Share, Share1,
    Smtavail, Temp, Users
]

for model_cls in _csv_models:
    form_name = f"{model_cls.__name__}Form"
    meta_cls = type("Meta", (ExcludeRawCSVDataForm.Meta,), {
        "model": model_cls,
        "fields": "__all__"
    })
    globals()[form_name] = type(form_name, (ExcludeRawCSVDataForm,), {
        "Meta": meta_cls
    })
