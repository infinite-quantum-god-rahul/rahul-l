# companies/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # ─────────  AUTH & CORE NAV  ─────────
    path("",                    views.home_view,       name="home"),
    path("login/",              views.login_view,      name="login"),
    path("logout/",             views.logout_view,     name="logout"),
    path("dashboard/",          views.dashboard_view,  name="dashboard"),
    path("switch-account/", views.switch_account, name="switch_account"),

    # ─────────  AJAX HELPERS  ─────────
    path("next_code/",                views.next_code_view, name="next_code"),
    path("search/client/aadhar/",     views.search_aadhar,  name="search_aadhar"),
    path("permission-group/",         views.permission_group, name="permission_group"),

    # ─────────  ENTITY CRUD  ─────────
    path("<str:entity>/get/",               views.entity_get,    name="entity_get_new"),      # create form
    path("<str:entity>/get/<int:pk>/",      views.entity_get,    name="entity_get"),          # edit form
    path("<str:entity>/create/",            views.entity_create, name="entity_create"),
    path("<str:entity>/update/<int:pk>/",   views.entity_update, name="entity_update"),
    path("<str:entity>/delete/<int:pk>/",   views.entity_delete, name="entity_delete"),

    # keep LAST so it doesn't swallow more specific routes
    path("<str:entity>/",                   views.entity_list,   name="entity_list"),
]
