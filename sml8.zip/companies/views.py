# companies/views.py
from functools import wraps
import json

from django.apps import apps
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group, Permission
from django.http import (
    JsonResponse,
    HttpResponseForbidden,
    HttpResponseNotAllowed,
)
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import render_to_string
from django.views.decorators.http import require_POST, require_GET

# >>> ADD: cache + csrf token tools for secure/throttled login
from django.core.cache import cache
from django.views.decorators.csrf import csrf_protect
from django.middleware.csrf import get_token

from .models import Company, Column, Client
from .forms import *

# ────────────────────────────────────────────────────────────────────
#  NEW ︱ user-profile ⇆ Django-auth sync helper
# ────────────────────────────────────────────────────────────────────
ROLE_GROUPS = {
    "is_master":     "Master",
    "is_data_entry": "DataEntry",
    "is_reports":    "Reports",
    "is_accounting": "Accounting",
}


def apply_profile_permissions(profile):
    """
    Convert the five Boolean flags on UserProfile into:
      • superuser / staff status (is_admin)
      • group membership (other flags)
    """
    user = profile.user
    # superuser power
    user.is_superuser = profile.is_admin
    user.is_staff = profile.is_admin
    # group sync
    user.groups.clear()
    for flag, group_name in ROLE_GROUPS.items():
        if getattr(profile, flag):
            grp, _ = Group.objects.get_or_create(name=group_name)
            user.groups.add(grp)
    user.save(update_fields=["is_superuser", "is_staff"])


# ────────────────────────────────────────────────────────────────────
#  Helpers
# ────────────────────────────────────────────────────────────────────
def is_staff_or_superuser(user):
    return user.is_authenticated and (user.is_superuser or user.is_staff)

# views.py
from django.contrib import auth
from django.shortcuts import redirect
from django.views.decorators.http import require_POST
from django.urls import reverse

@require_POST
def switch_account(request):
    # End current session
    auth.logout(request)
    # Send them to login; optionally preserve where they were going:
    # next_url = request.POST.get("next") or request.GET.get("next") or "/"
    # return redirect(f"{reverse('login')}?next={next_url}")
    return redirect(reverse("login"))

def is_ajax(request):
    return request.headers.get("X-Requested-With") == "XMLHttpRequest" or request.META.get(
        "HTTP_X_REQUESTED_WITH"
    ) == "XMLHttpRequest"


def ajax_login_required_or_redirect(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not request.user.is_authenticated:
            if is_ajax(request):
                return JsonResponse(
                    {"success": False, "error": "Authentication required"}, status=401
                )
            return redirect(f"{settings.LOGIN_URL}?next={request.path}")
        return view_func(request, *args, **kwargs)

    return _wrapped


# ────────────────────────────────────────────────────────────────────
#  Auth Views
# ────────────────────────────────────────────────────────────────────
def home_view(request):
    return render(request, "home.html")


# >>> ADD: login security constants + IP helper (kept minimal and local to auth section)
ATTEMPT_KEY = "login_attempts:{ip}:{u}"
LOCK_KEY = "login_lock:{ip}:{u}"
MAX_ATTEMPTS = 5          # after this, short lock (SBI-style soft lock)
OTP_REQUIRED_AFTER = 3    # ask OTP after 3 consecutive failures
LOCK_SECONDS = 60         # lockout window (seconds)


def _client_ip(request):
    fwd = request.META.get("HTTP_X_FORWARDED_FOR")
    if fwd:
        return fwd.split(",")[0].strip()
    return (request.META.get("REMOTE_ADDR") or "unknown").strip()


@csrf_protect
def login_view(request):
    # Keep GET behavior (render home) for non-AJAX initial loads
    if request.method != "POST":
        # Ensure CSRF cookie present
        get_token(request)
        return render(request, "home.html")

    username = (request.POST.get("username") or "").strip()
    password = request.POST.get("password") or ""
    otp = request.POST.get("otp") or ""
    remember = request.POST.get("remember") == "on"

    ip = _client_ip(request)
    attempt_key = ATTEMPT_KEY.format(ip=ip, u=username or "_")
    lock_key = LOCK_KEY.format(ip=ip, u=username or "_")

    # If currently locked, surface a throttled response
    if cache.get(lock_key):
        return JsonResponse({"success": False, "error": "Too many attempts. Please wait a minute."}, status=429)

    attempts = int(cache.get(attempt_key) or 0)

    # If enough failures occurred earlier, require OTP now
    if attempts >= OTP_REQUIRED_AFTER and not otp:
        # Ask the front-end to show the OTP field; keep HTTP 200 to allow UI flow
        return JsonResponse({"success": False, "require_otp": True, "error": "OTP required"}, status=200)

    user = authenticate(request, username=username, password=password)

    # Minimal inline OTP check (hook up django-otp/SMS/email later)
    def verify_otp(otp_code: str) -> bool:
        if attempts < OTP_REQUIRED_AFTER:
            return True  # not required yet
        # Simple format check; replace with real TOTP/SMS validation in production
        return bool(otp_code and otp_code.isdigit() and 4 <= len(otp_code) <= 8)

    if user and is_staff_or_superuser(user) and verify_otp(otp):
        login(request, user)

        # Session duration honoring "remember me"
        if remember:
            # 14 days
            request.session.set_expiry(14 * 24 * 3600)
        else:
            # expire at browser close
            request.session.set_expiry(0)

        # Clear counters
        cache.delete(attempt_key)
        cache.delete(lock_key)

        # Preserve your original JSON contract (redirect_url key)
        return JsonResponse({"success": True, "redirect_url": "/dashboard/"})

    # Fail path: increment attempts and possibly lock
    attempts += 1
    cache.set(attempt_key, attempts, timeout=LOCK_SECONDS * 3)

    if attempts >= MAX_ATTEMPTS:
        cache.set(lock_key, True, timeout=LOCK_SECONDS)
        return JsonResponse({"success": False, "error": "Account temporarily locked due to failed attempts."}, status=429)

    # Tell UI whether to show OTP now; preserve error text
    return JsonResponse({
        "success": False,
        "error": "Invalid credentials or permission denied",
        "require_otp": attempts >= OTP_REQUIRED_AFTER
    }, status=200)


@login_required
def logout_view(request):
    logout(request)
    return redirect("home")


# ────────────────────────────────────────────────────────────────────
#  Dashboard
# ────────────────────────────────────────────────────────────────────
@login_required
def dashboard_view(request):
    user = request.user
    display_name = user.get_full_name() or user.username
    branch_name = ""
    role_label = None
    profile = getattr(user, "userprofile", None)

    if profile:
        if profile.branch:
            branch_name = profile.branch.name
        if profile.is_admin:
            role_label = "Admin"
        elif profile.is_master:
            role_label = "Master"
        elif profile.is_data_entry:
            role_label = "Data Entry"
        elif profile.is_reports:
            role_label = "Reports"
        elif profile.is_accounting:
            role_label = "Accounting"

    return render(
        request,
        "dashboard.html",
        {
            "staff_info": getattr(user, "staff_info", None),
            "header_user_display_name": display_name,
            "header_branch_name": branch_name,
            "header_role_label": role_label or ("Superuser" if user.is_superuser else "Staff" if user.is_staff else None),
        },
    )



# ────────────────────────────────────────────────────────────────────
#  Entity utilities
# ────────────────────────────────────────────────────────────────────
def get_model_class(entity):
    try:
        return apps.get_model("companies", entity)
    except LookupError:
        return None


def get_form_class(entity):
    name = f"{entity.capitalize()}Form"
    form_class = globals().get(name)
    if form_class:
        return form_class
    parts = entity.split("_")
    camel = "".join(p.capitalize() for p in parts)
    alt_name = f"{camel}Form"
    form_class = globals().get(alt_name)
    if form_class:
        return form_class
    lower_entity = entity.replace("_", "").lower()
    for obj in globals().values():
        if isinstance(obj, type) and obj.__name__.lower().endswith("form"):
            candidate = obj.__name__.lower().replace("form", "")
            if candidate == lower_entity or lower_entity in candidate:
                return obj
    return None


def get_section_map(entity):
    """Optional explicit mapping; most forms now self-define section_map."""
    return {
        "clientjoiningform": {
            "Personal Info": ["member", "joined_on", "referred_by"],
            "Meta": ["joining_date"],  # optional extra section if needed
        },
        "staff": {
            "Staff Details": ["name", "joining_date", "branch"]
        },
        "loanapplication": {
            "Loan Info": ["client", "product", "amount_requested", "applied_date"],
            "Meta": ["joining_date"],  # if this model has it
        },
        "userprofile": {
            "User Setup": ["user", "branch", "role", "joining_date"],
            "Permissions": [
                "is_admin",
                "is_master",
                "is_data_entry",
                "is_reports",
                "is_accounting",
            ],
            "Status": ["status"],
        },
        "role": {
            "Role Details": ["name"]
        },
    }.get(entity.lower(), None)



# ────────────────────────────────────────────────────────────────────
#  CRUD Views
# ────────────────────────────────────────────────────────────────────
pretty_names = {
    "loanapplication": "Loan Application",
    "clientjoiningform": "Client Joining Form",
    "userprofile": "User Profile",
    "staff": "Staff Registration",
    "role": "Role Management",
    "product": "Products Management",
    "company": "Company",
    "branch": "Branch",
    "village": "Village",
    "center": "Center",
    "group": "Group",
    "column": "Column",
    "businesssetting": "Business Setting Rules",
    # Add more if needed...
}

@login_required
def entity_list(request, entity):
    model = get_model_class(entity)
    if model is None:
        return JsonResponse(
            {"success": False, "error": f'Model for entity "{entity}" not found.'},
            status=404,
        )

    objects = model.objects.all()
    grouped_objects = {"All Records": objects}

    # ✅ Get dynamic columns from Column model for this entity
    column_fields = Column.objects.filter(module__iexact=entity).order_by("order")

    context = {
        "include_template": "companies/grid_list.html",
        "entity": entity,
        "pretty_entity": pretty_names.get(entity, entity.replace("_", " ").title()),
        "grouped_objects": grouped_objects,
        "staff_info": getattr(request.user, "staff_info", None),
        "column_fields": column_fields,
    }
    return render(request, "dashboard.html", context)

@ajax_login_required_or_redirect
@require_POST
def entity_create(request, entity):
    form_class = get_form_class(entity)
    if not form_class:
        return JsonResponse(
            {"success": False, "error": f'Form class for entity "{entity}" not found.'},
            status=400,
        )

    # ✅ Get dynamic Column fields and pass to form
    extra_fields = Column.objects.filter(module__iexact=entity).order_by("order")
    form = form_class(request.POST, request.FILES, extra_fields=extra_fields)

    if form.is_valid():
        instance = form.save(commit=False)
        if entity.lower() == "column":
            instance.company_id = 1

        # ✅ Safely merge extra_data fields
        instance.extra_data = instance.extra_data or {}
        for k, v in request.POST.items():
            if k.startswith("extra__"):
                field_key = k.replace("extra__", "")
                instance.extra_data[field_key] = v

        instance.save()
        form.save_m2m()

        if entity.lower() == "userprofile":
            apply_profile_permissions(instance)

        return JsonResponse({"success": True})

    return JsonResponse({"success": False, "errors": form.errors})


@ajax_login_required_or_redirect
def entity_get(request, entity, pk=None):
    if request.method != "GET":
        return HttpResponseNotAllowed(["GET"])

    model = get_model_class(entity)
    if model is None:
        return JsonResponse(
            {"success": False, "error": f'Model for entity "{entity}" not found.'},
            status=404,
        )

    form_class = get_form_class(entity)
    if not form_class:
        return JsonResponse(
            {"success": False, "error": f'Form class for entity "{entity}" not found.'},
            status=400,
        )

    # ✅ Load dynamic Column fields
    extra_fields = Column.objects.filter(module__iexact=entity).order_by("order")

    edit_mode = False
    object_id = ""
    if pk:
        obj = get_object_or_404(model, pk=pk)
        form = form_class(instance=obj, extra_fields=extra_fields)
        edit_mode = True
        object_id = pk
    else:
        model = get_model_class(entity)
        obj = model()
        obj.code = obj._next_code() if hasattr(obj, "_next_code") else ""
        form = form_class(instance=obj, extra_fields=extra_fields)

    html = render_to_string(
        "companies/modal_form.html",
        {
            "form": form,
            "entity": entity,
            "edit_mode": edit_mode,
            "object_id": object_id,
            "section_map": get_section_map(entity),
            "extra_fields": extra_fields,
        },
        request=request,
    )
    return JsonResponse({"success": True, "html": html})


@ajax_login_required_or_redirect
@require_POST
def entity_update(request, entity, pk):
    model = get_model_class(entity)
    if model is None:
        return JsonResponse(
            {"success": False, "error": f'Model for entity "{entity}" not found.'},
            status=404,
        )

    obj = get_object_or_404(model, pk=pk)
    form_class = get_form_class(entity)
    if not form_class:
        return JsonResponse(
            {"success": False, "error": f'Form class for entity "{entity}" not found.'},
            status=400,
        )

    # ✅ Get dynamic fields and inject
    extra_fields = Column.objects.filter(module__iexact=entity).order_by("order")
    form = form_class(request.POST, request.FILES, instance=obj, extra_fields=extra_fields)

    if form.is_valid():
        instance = form.save(commit=False)

        # ✅ Merge dynamic data instead of overwriting
        instance.extra_data = instance.extra_data or {}
        for k, v in request.POST.items():
            if k.startswith("extra__"):
                field_key = k.replace("extra__", "")
                instance.extra_data[field_key] = v

        instance.save()
        form.save_m2m()

        if entity.lower() == "userprofile":
            apply_profile_permissions(instance)

        return JsonResponse({"success": True})

    return JsonResponse({"success": False, "errors": form.errors})

@ajax_login_required_or_redirect
@require_POST
def entity_delete(request, entity, pk):
    model = get_model_class(entity)
    if model is None:
        return JsonResponse(
            {"success": False, "error": f'Model for entity "{entity}" not found.'},
            status=404,
        )

    obj = get_object_or_404(model, pk=pk)
    obj.delete()
    return JsonResponse({"success": True})


# ────────────────────────────────────────────────────────────────────
#  Code generator (CMP001 / CL1001 …)
# ────────────────────────────────────────────────────────────────────
@ajax_login_required_or_redirect
@require_POST
def next_code_view(request):
    entity = request.POST.get("entity")
    model = get_model_class(entity)
    if model is None:
        return JsonResponse(
            {"success": False, "error": f'Model for entity "{entity}" not found.'},
            status=404,
        )

    prefix = request.POST.get("prefix", "")
    count = model.objects.count() + 1
    code = f"{prefix}{str(count).zfill(3)}"
    return JsonResponse({"code": code})


# ────────────────────────────────────────────────────────────────────
#  Permissions UI
# ────────────────────────────────────────────────────────────────────
@login_required
def permission_group(request):
    groups = Group.objects.all()
    permissions = Permission.objects.all()
    return render(
        request, "companies/permission_group.html", {"groups": groups, "permissions": permissions}
    )


# ────────────────────────────────────────────────────────────────────
#  Aadhaar type-ahead (Client Joining modal)
# ────────────────────────────────────────────────────────────────────
@require_GET
@login_required
def search_aadhar(request):
    q = request.GET.get("q", "").replace(" ", "")
    data = []
    if q:
        clients = Client.objects.filter(aadhar__startswith=q)[:10]
        data = [{"id": c.id, "name": c.name, "aadhar": c.aadhar} for c in clients]
    return JsonResponse(data, safe=False)
